/**
 * @module botframework-config
 */
/**
 * Copyright(c) Microsoft Corporation.All rights reserved.
 * Licensed under the MIT License.
 */
import { ServiceTypes } from './schema';
/**
 * @private
 */
export interface IResource {
    readonly type: ServiceTypes;
    id?: string;
    name: string;
}
/**
 * @private
 */
export interface IUrlResource extends IResource {
    url: string;
}
/**
 * @private
 */
export interface IDispatchResource extends IResource {
    serviceIds: string[];
}
/**
 * @private
 */
export interface IBlobResource extends IResource {
    container: string;
}
/**
 * @private
 */
export interface ICosmosDBResource extends IResource {
    database: string;
    collection: string;
}
/**
 * @private
 */
export interface IFileResource extends IResource {
    path: string;
}
/**
 * @private
 */
export interface IGenericResource extends IUrlResource {
    configuration: {
        [key: string]: string;
    };
}
/**
 * @private
 * This is class which allows you to manipulate in memory representations of bot configuration
 * with no nodejs depedencies.
 */
export declare class BotRecipe {
    /**
     * Version of the recipe.
     */
    version: string;
    /**
     *
     */
    resources: IResource[];
    /**
     * Creates a new BotRecipe instance.
     */
    constructor();
    static fromJSON(source?: Partial<BotRecipe>): BotRecipe;
    toJSON(): Partial<BotRecipe>;
}
