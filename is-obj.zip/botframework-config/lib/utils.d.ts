/**
 * @module botframework-config
 */
/**
 * Copyright(c) Microsoft Corporation.All rights reserved.
 * Licensed under the MIT License.
 */
/**
 * @private
 * @param value
 */
export declare function uuidValidate(value: string): boolean;
