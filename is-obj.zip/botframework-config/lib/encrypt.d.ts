/**
 * @module botframework-config
 */
/**
 * Copyright(c) Microsoft Corporation.All rights reserved.
 * Licensed under the MIT License.
 */
/**
 * @private
 */
export declare function generateKey(): string;
/**
 * @private
 * Encrypt a string using standardized encyryption of AES256
 * @param plainText value to encrypt
 * @param secret secret to use
 */
export declare function encryptString(plainText: string, secret: string): string;
/**
 * @private
 * Decrypt a string using standardized encyryption of AES256
 * @param enryptedValue value to decrypt
 * @param secret secret to use
 */
export declare function decryptString(encryptedValue: string, secret: string): string;
/**
 * @private
 * @param encryptedValue
 * @param secret
 */
export declare function legacyDecrypt(encryptedValue: string, secret: string): string;
