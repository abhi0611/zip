/**
 * @module botframework-config
 */
/**
 * Copyright(c) Microsoft Corporation.All rights reserved.
 * Licensed under the MIT License.
 */
import { IFileService } from '../schema';
import { ConnectedService } from './connectedService';
/**
 * Defines an file service connection.
 */
export declare class FileService extends ConnectedService implements IFileService {
    /**
     * File path.
     */
    path: string;
    /**
     * Creates a new FileService instance.
     * @param source (Optional) JSON based service definition.
     */
    constructor(source?: IFileService);
    encrypt(secret: string, encryptString: (value: string, secret: string) => string): void;
    decrypt(secret: string, decryptString: (value: string, secret: string) => string): void;
}
