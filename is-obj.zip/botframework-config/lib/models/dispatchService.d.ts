/**
 * @module botframework-config
 */
/**
 * Copyright(c) Microsoft Corporation.All rights reserved.
 * Licensed under the MIT License.
 */
import { IDispatchService } from '../schema';
import { LuisService } from './luisService';
/**
 * Defines a dispatch service connection.
 */
export declare class DispatchService extends LuisService implements IDispatchService {
    /**
     * Service IDs that the dispatch model will dispatch across.
     */
    serviceIds: string[];
    /**
     * Creates a new DispatchService instance.
     * @param source (Optional) JSON based service definition.
     */
    constructor(source?: IDispatchService);
}
