/**
 * @module botframework-config
 */
/**
 * Copyright(c) Microsoft Corporation.All rights reserved.
 * Licensed under the MIT License.
 */
import { IGenericService } from '../schema';
import { ConnectedService } from './connectedService';
/**
 * Defines a generic service connection.
 */
export declare class GenericService extends ConnectedService implements IGenericService {
    /**
     * Deep link to service.
     */
    url: string;
    /**
     * Named/value configuration data.
     */
    configuration: {
        [key: string]: string;
    };
    /**
     * Creates a new GenericService instance.
     * @param source (Optional) JSON based service definition.
     */
    constructor(source?: IGenericService);
    encrypt(secret: string, encryptString: (value: string, secret: string) => string): void;
    decrypt(secret: string, decryptString: (value: string, secret: string) => string): void;
}
