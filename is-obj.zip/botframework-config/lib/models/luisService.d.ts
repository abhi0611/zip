/**
 * @module botframework-config
 */
/**
 * Copyright(c) Microsoft Corporation.All rights reserved.
 * Licensed under the MIT License.
 */
import { ILuisService, ServiceTypes } from '../schema';
import { ConnectedService } from './connectedService';
/**
 * Defines a LUIS service connection.
 */
export declare class LuisService extends ConnectedService implements ILuisService {
    /**
     * Luis app ID.
     */
    appId: string;
    /**
     * Authoring key for using authoring api.
     */
    authoringKey: string;
    /**
     * Subscription key for using calling model api for predictions.
     */
    subscriptionKey: string;
    /**
     * Version of the application.
     */
    version: string;
    /**
     * Region for luis.
     */
    region: string;
    /**
     * Creates a new LuisService instance.
     * @param source (Optional) JSON based service definition.
     * @param type (Optional) type of service being defined.
     */
    constructor(source?: ILuisService, serviceType?: ServiceTypes);
    getEndpoint(): string;
    encrypt(secret: string, encryptString: (value: string, secret: string) => string): void;
    decrypt(secret: string, decryptString: (value: string, secret: string) => string): void;
}
