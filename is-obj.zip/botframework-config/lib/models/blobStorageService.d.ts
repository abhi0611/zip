/**
 * @module botframework-config
 */
/**
 * Copyright(c) Microsoft Corporation.All rights reserved.
 * Licensed under the MIT License.
 */
import { IBlobStorageService } from '../schema';
import { AzureService } from './azureService';
/**
 * Defines an blob storage service connection.
 */
export declare class BlobStorageService extends AzureService implements IBlobStorageService {
    /**
     * Connection string for blob storage.
     */
    connectionString: string;
    /**
     * (Optional) container name.
     */
    container: string;
    /**
     * Creates a new BlobStorageService instance.
     * @param source (Optional) JSON based service definition.
     */
    constructor(source?: IBlobStorageService);
    encrypt(secret: string, encryptString: (value: string, secret: string) => string): void;
    decrypt(secret: string, decryptString: (value: string, secret: string) => string): void;
}
