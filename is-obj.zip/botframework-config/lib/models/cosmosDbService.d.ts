/**
 * @module botframework-config
 */
/**
 * Copyright(c) Microsoft Corporation.All rights reserved.
 * Licensed under the MIT License.
 */
import { ICosmosDBService } from '../schema';
import { AzureService } from './azureService';
/**
 * Defines a CosmosDB service connection.
 */
export declare class CosmosDbService extends AzureService implements ICosmosDBService {
    /**
     * Endpoint/uri for CosmosDB.
     */
    endpoint: string;
    /**
     * Key for accessing CosmosDB.
     */
    key: string;
    /**
     * Database name.
     */
    database: string;
    /**
     * Collection name.
     */
    collection: string;
    /**
     * Creates a new CosmosDBService instance.
     * @param source (Optional) JSON based service definition.
     */
    constructor(source?: ICosmosDBService);
    encrypt(secret: string, encryptString: (value: string, secret: string) => string): void;
    decrypt(secret: string, decryptString: (value: string, secret: string) => string): void;
}
