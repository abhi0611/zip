import { IQnAService } from '../schema';
import { ConnectedService } from './connectedService';
/**
 * Defines a QnA Maker service connection.
 */
export declare class QnaMakerService extends ConnectedService implements IQnAService {
    /**
     * Knowledge base id.
     */
    kbId: string;
    /**
     * Subscription key for calling admin api.
     */
    subscriptionKey: string;
    /**
     * hostname for private service endpoint Example: https://myqna.azurewebsites.net.
     */
    hostname: string;
    /**
     * Endpoint Key for querying the kb.
     */
    endpointKey: string;
    /**
     * Creates a new QnaMakerService instance.
     * @param source (Optional) JSON based service definition.
     */
    constructor(source?: IQnAService);
    encrypt(secret: string, encryptString: (value: string, secret: string) => string): void;
    decrypt(secret: string, decryptString: (value: string, secret: string) => string): void;
}
