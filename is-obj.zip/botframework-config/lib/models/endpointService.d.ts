/**
 * @module botframework-config
 */
/**
 * Copyright(c) Microsoft Corporation.All rights reserved.
 * Licensed under the MIT License.
 */
import { IEndpointService } from '../schema';
import { ConnectedService } from './connectedService';
/**
 * Defines an endpoint service connection.
 */
export declare class EndpointService extends ConnectedService implements IEndpointService {
    /**
     * MSA App ID.
     */
    appId: string;
    /**
     * MSA app password for the bot.
     */
    appPassword: string;
    /**
     * Endpoint of localhost service.
     */
    endpoint: string;
    /**
     * The channel service (Azure or US Government Azure) for the bot.
     * A value of 'https://botframework.azure.us' means the bot will be talking to a US Government Azure data center.
     * An undefined or null value means the bot will be talking to public Azure
     */
    channelService: string;
    /**
     * Creates a new EndpointService instance.
     * @param source JSON based service definition.
     */
    constructor(source: IEndpointService);
    encrypt(secret: string, encryptString: (value: string, secret: string) => string): void;
    decrypt(secret: string, decryptString: (value: string, secret: string) => string): void;
}
