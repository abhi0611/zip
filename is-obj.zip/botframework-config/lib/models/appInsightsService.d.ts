/**
 * @module botframework-config
 */
/**
 * Copyright(c) Microsoft Corporation.All rights reserved.
 * Licensed under the MIT License.
 */
import { IAppInsightsService } from '../schema';
import { AzureService } from './azureService';
/**
 * Defines an App Insights service connection.
 */
export declare class AppInsightsService extends AzureService implements IAppInsightsService {
    /**
     * Instrumentation key for logging data to appInsights.
     */
    instrumentationKey: string;
    /**
     * (Optional) application ID used for programmatic access to AppInsights.
     */
    applicationId: string;
    /**
     * (Optional) named api keys for programmatic access to AppInsights.
     */
    apiKeys: {
        [key: string]: string;
    };
    /**
     * Creates a new AppInsightService instance.
     * @param source (Optional) JSON based service definition.
     */
    constructor(source?: IAppInsightsService);
    encrypt(secret: string, encryptString: (value: string, secret: string) => string): void;
    decrypt(secret: string, decryptString: (value: string, secret: string) => string): void;
}
