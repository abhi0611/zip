/**
 * @module botframework-config
 */
/**
 * Copyright(c) Microsoft Corporation.All rights reserved.
 * Licensed under the MIT License.
 */
import { IBotService } from '../schema';
import { AzureService } from './azureService';
/**
 * Defines an Azure Bot Service connection.
 */
export declare class BotService extends AzureService implements IBotService {
    /**
     * MSA App ID for the bot.
     */
    appId: string;
    /**
     * Creates a new BotService instance.
     * @param source (Optional) JSON based service definition.
     */
    constructor(source?: IBotService);
    encrypt(secret: string, encryptString: (value: string, secret: string) => string): void;
    decrypt(secret: string, decryptString: (value: string, secret: string) => string): void;
}
