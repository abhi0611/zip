/**
 * @module botframework-config
 */
/**
 * Copyright(c) Microsoft Corporation.All rights reserved.
 * Licensed under the MIT License.
 */
import { ConnectedService } from './models';
import { IBotConfiguration, IConnectedService } from './schema';
/**
 * This is class which allows you to manipulate in memory representations of bot configuration with
 * no nodejs depedencies.
 */
export declare class BotConfigurationBase implements Partial<IBotConfiguration> {
    name: string;
    description: string;
    services: IConnectedService[];
    padlock: string;
    version: string;
    /**
     * Creates a new BotConfigutationBase instance.
     */
    constructor();
    /**
     * Returns a ConnectedService instance given a JSON based service configuration.
     * @param service JSON based service configuration.
     */
    static serviceFromJSON(service: IConnectedService): ConnectedService;
    /**
     * Returns a new BotConfigurationBase instance given a JSON based configuration.
     * @param source JSON based configuration.
     */
    static fromJSON(source?: Partial<IBotConfiguration>): BotConfigurationBase;
    /**
     * Returns a JSON based version of the current bot.
     */
    toJSON(): IBotConfiguration;
    /**
     * Connect a service to the bot file.
     * @param newService Service to add.
     * @returns Assigned ID for the service.
     */
    connectService(newService: IConnectedService): string;
    /**
     * Find service by id.
     * @param id ID of the service to find.
     */
    findService(id: string): IConnectedService;
    /**
     * Find service by name or id.
     * @param nameOrId Name or ID of the service to find.
     */
    findServiceByNameOrId(nameOrId: string): IConnectedService;
    /**
     * Remove service by name or id.
     * @param nameOrId Name or ID of the service to remove.
     */
    disconnectServiceByNameOrId(nameOrId: string): IConnectedService;
    /**
     * Remove service by id.
     * @param nameOrId ID of the service to remove.
     */
    disconnectService(id: string): void;
    /**
     * Migrate old formated data into new format.
     */
    protected migrateData(): void;
}
