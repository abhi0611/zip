import { BotConfigurationBase } from './botConfigurationBase';
import { IBotConfiguration } from './schema';
/**
 * BotConfiguration represents configuration information for a bot.
 *
 * @remarks
 * It is typically loaded from a .bot file on disk. This class implements methods for encrypting
 * and manipulating the in-memory representation of the configuration.
 */
export declare class BotConfiguration extends BotConfigurationBase {
    private internal;
    /**
     * Returns a new BotConfiguration instance given a JSON based configuration.
     * @param source JSON based configuration.
     */
    static fromJSON(source?: Partial<IBotConfiguration>): BotConfiguration;
    /**
     * Load the bot configuration by looking in a folder and loading the first .bot file in the
     * folder.
     * @param folder (Optional) folder to look for bot files. If not specified the current working directory is used.
     * @param secret (Optional) secret used to decrypt the bot file.
     */
    static loadBotFromFolder(folder?: string, secret?: string): Promise<BotConfiguration>;
    /**
     * Load the bot configuration by looking in a folder and loading the first .bot file in the
     * folder. (blocking)
     * @param folder (Optional) folder to look for bot files. If not specified the current working directory is used.
     * @param secret (Optional) secret used to decrypt the bot file.
     */
    static loadBotFromFolderSync(folder?: string, secret?: string): BotConfiguration;
    /**
     * Load the configuration from a .bot file.
     * @param botpath Path to bot file.
     * @param secret (Optional) secret used to decrypt the bot file.
     */
    static load(botpath: string, secret?: string): Promise<BotConfiguration>;
    /**
     * Load the configuration from a .bot file. (blocking)
     * @param botpath Path to bot file.
     * @param secret (Optional) secret used to decrypt the bot file.
     */
    static loadSync(botpath: string, secret?: string): BotConfiguration;
    /**
     * Generate a new key suitable for encrypting.
     */
    static generateKey(): string;
    private static internalLoad;
    /**
     * Save the configuration to a .bot file.
     * @param botpath Path to bot file.
     * @param secret (Optional) secret used to encrypt the bot file.
     */
    saveAs(botpath: string, secret?: string): Promise<void>;
    /**
     * Save the configuration to a .bot file. (blocking)
     * @param botpath Path to bot file.
     * @param secret (Optional) secret used to encrypt the bot file.
     */
    saveAsSync(botpath: string, secret?: string): void;
    /**
     * Save the file with secret.
     * @param secret (Optional) secret used to encrypt the bot file.
     */
    save(secret?: string): Promise<void>;
    /**
     * Save the file with secret. (blocking)
     * @param secret (Optional) secret used to encrypt the bot file.
     */
    saveSync(secret?: string): void;
    /**
     * Clear secret.
     */
    clearSecret(): void;
    /**
     * Encrypt all values in the in memory config.
     * @param secret Secret to encrypt.
     */
    encrypt(secret: string): void;
    /**
     * Decrypt all values in the in memory config.
     * @param secret Secret to decrypt.
     */
    decrypt(secret?: string): void;
    /**
     * Return the path that this config was loaded from.  .save() will save to this path.
     */
    getPath(): string;
    /**
     * Make sure secret is correct by decrypting the secretKey with it.
     * @param secret Secret to use.
     */
    validateSecret(secret: string): void;
    private savePrep;
}
