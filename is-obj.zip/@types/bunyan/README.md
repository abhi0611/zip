# Installation
> `npm install --save @types/bunyan`

# Summary
This package contains type definitions for bunyan (https://github.com/trentm/node-bunyan).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/bunyan

Additional Details
 * Last updated: Tue, 09 Oct 2018 21:20:25 GMT
 * Dependencies: node
 * Global values: none

# Credits
These definitions were written by Alex Mikhalev <https://github.com/amikhalev>.
