# Installation
> `npm install --save @types/filenamify`

# Summary
This package contains type definitions for filenamify (https://github.com/sindresorhus/filenamify).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/filenamify

Additional Details
 * Last updated: Mon, 21 Aug 2017 21:49:18 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Junyoung Choi <https://github.com/rokt33r>.
