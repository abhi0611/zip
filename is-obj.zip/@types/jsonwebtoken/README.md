# Installation
> `npm install --save @types/jsonwebtoken`

# Summary
This package contains type definitions for jsonwebtoken (https://github.com/auth0/node-jsonwebtoken).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/jsonwebtoken

Additional Details
 * Last updated: Mon, 02 Jul 2018 20:44:33 GMT
 * Dependencies: node
 * Global values: none

# Credits
These definitions were written by Maxime LUCE <https://github.com/SomaticIT>, Daniel Heim <https://github.com/danielheim>, Brice BERNARD <https://github.com/brikou>, Veli-Pekka Kestilä <https://github.com/vpk>.
