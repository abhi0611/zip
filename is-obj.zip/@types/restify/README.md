# Installation
> `npm install --save @types/restify`

# Summary
This package contains type definitions for restify (https://github.com/restify/node-restify).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/restify

Additional Details
 * Last updated: Thu, 23 Aug 2018 17:24:04 GMT
 * Dependencies: http, https, bunyan, url, spdy, stream, zlib, node
 * Global values: none

# Credits
These definitions were written by Bret Little <https://github.com/blittle>, Steve Hipwell <https://github.com/stevehipwell>, Leandro Almeida <https://github.com/leanazulyoro>, Mitchell Bundy <https://github.com/mgebundy>.
