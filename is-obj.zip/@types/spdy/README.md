# Installation
> `npm install --save @types/spdy`

# Summary
This package contains type definitions for node-spdy (https://github.com/indutny/node-spdy).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/spdy

Additional Details
 * Last updated: Fri, 06 Oct 2017 20:55:55 GMT
 * Dependencies: http, https, node
 * Global values: none

# Credits
These definitions were written by Anthony Trinh <https://github.com/tony19>.
