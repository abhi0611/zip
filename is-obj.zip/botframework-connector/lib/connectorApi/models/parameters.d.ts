import * as msRest from "ms-rest-js";
export declare const activityId: msRest.OperationURLParameter;
export declare const attachmentId: msRest.OperationURLParameter;
export declare const continuationToken: msRest.OperationQueryParameter;
export declare const conversationId: msRest.OperationURLParameter;
export declare const memberId: msRest.OperationURLParameter;
export declare const pageSize: msRest.OperationQueryParameter;
export declare const viewId: msRest.OperationURLParameter;
