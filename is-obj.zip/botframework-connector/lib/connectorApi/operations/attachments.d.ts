import * as msRest from "ms-rest-js";
import * as Models from "botframework-schema";
import { ConnectorClientContext } from "../connectorClientContext";
/** Class representing a Attachments. */
export declare class Attachments {
    private readonly client;
    /**
     * Create a Attachments.
     * @param {ConnectorClientContext} client Reference to the service client.
     */
    constructor(client: ConnectorClientContext);
    /**
     * Get AttachmentInfo structure describing the attachment views
     * @summary GetAttachmentInfo
     * @param attachmentId attachment id
     * @param [options] The optional parameters
     * @returns Promise<Models.AttachmentsGetAttachmentInfoResponse>
     */
    getAttachmentInfo(attachmentId: string, options?: msRest.RequestOptionsBase): Promise<Models.AttachmentsGetAttachmentInfoResponse>;
    /**
     * @param attachmentId attachment id
     * @param callback The callback
     */
    getAttachmentInfo(attachmentId: string, callback: msRest.ServiceCallback<Models.AttachmentInfo>): void;
    /**
     * @param attachmentId attachment id
     * @param options The optional parameters
     * @param callback The callback
     */
    getAttachmentInfo(attachmentId: string, options: msRest.RequestOptionsBase, callback: msRest.ServiceCallback<Models.AttachmentInfo>): void;
    /**
     * Get the named view as binary content
     * @summary GetAttachment
     * @param attachmentId attachment id
     * @param viewId View id from attachmentInfo
     * @param [options] The optional parameters
     * @returns Promise<Models.AttachmentsGetAttachmentResponse>
     */
    getAttachment(attachmentId: string, viewId: string, options?: msRest.RequestOptionsBase): Promise<Models.AttachmentsGetAttachmentResponse>;
    /**
     * @param attachmentId attachment id
     * @param viewId View id from attachmentInfo
     * @param callback The callback
     */
    getAttachment(attachmentId: string, viewId: string, callback: msRest.ServiceCallback<void>): void;
    /**
     * @param attachmentId attachment id
     * @param viewId View id from attachmentInfo
     * @param options The optional parameters
     * @param callback The callback
     */
    getAttachment(attachmentId: string, viewId: string, options: msRest.RequestOptionsBase, callback: msRest.ServiceCallback<void>): void;
}
