import * as msRest from "ms-rest-js";
import * as Models from "botframework-schema";
import * as Mappers from "./models/mappers";
import * as operations from "./operations";
import { ConnectorClientContext } from "./connectorClientContext";
declare class ConnectorClient extends ConnectorClientContext {
    attachments: operations.Attachments;
    conversations: operations.Conversations;
    /**
     * Initializes a new instance of the ConnectorClient class.
     * @param credentials Subscription credentials which uniquely identify client subscription.
     * @param [options] The parameter options
     */
    constructor(credentials: msRest.ServiceClientCredentials, options?: Models.ConnectorClientOptions);
}
export { ConnectorClient, ConnectorClientContext, Models as ConnectorModels, Mappers as ConnectorMappers };
export * from "./operations";
