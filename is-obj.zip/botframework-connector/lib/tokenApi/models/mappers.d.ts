import * as msRest from "ms-rest-js";
export declare const TokenResponse: msRest.CompositeMapper;
export declare const InnerHttpError: msRest.CompositeMapper;
export declare const ErrorModel: msRest.CompositeMapper;
export declare const ErrorResponse: msRest.CompositeMapper;
export declare const AadResourceUrls: msRest.CompositeMapper;
export declare const TokenStatus: msRest.CompositeMapper;
