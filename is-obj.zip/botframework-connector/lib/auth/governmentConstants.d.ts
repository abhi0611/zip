/**
 * @module botbuilder
 */
/**
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
export declare module GovernmentConstants {
    /**
     * Government Channel Service property value
     */
    const ChannelService: string;
    /**
     * TO CHANNEL FROM BOT: Login URL
     */
    const ToChannelFromBotLoginUrl: string;
    /**
     * TO CHANNEL FROM BOT: OAuth scope to request
     */
    const ToChannelFromBotOAuthScope: string;
    /**
     * TO BOT FROM CHANNEL: Token issuer
     */
    const ToBotFromChannelTokenIssuer: string;
    /**
     * TO BOT FROM CHANNEL: OpenID metadata document for tokens coming from MSA
     */
    const ToBotFromChannelOpenIdMetadataUrl: string;
    /**
     * TO BOT FROM GOV EMULATOR: OpenID metadata document for tokens coming from MSA
     */
    const ToBotFromEmulatorOpenIdMetadataUrl: string;
}
