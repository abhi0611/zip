/**
 * @module botbuilder
 */
/**
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
import { MicrosoftAppCredentials } from "./auth/microsoftAppCredentials";
export declare class EmulatorApiClient {
    static emulateOAuthCards(credentials: MicrosoftAppCredentials, emulatorUrl: string, emulate: boolean): Promise<boolean>;
}
