# Microsoft.Recognizers.Text for JavaScript

This module (`recognizers-text-sequence`) is a sub-module of `recognizers-text-suite`.

Please check the [main README](https://github.com/Microsoft/Recognizers-Text/tree/master/JavaScript/packages/recognizers-text-suite) for more details.